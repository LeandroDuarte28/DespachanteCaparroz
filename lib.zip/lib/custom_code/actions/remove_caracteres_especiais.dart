// Automatic FlutterFlow imports
import '/backend/schema/structs/index.dart';
import '/backend/supabase/supabase.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

Future<String> removeCaracteresEspeciais(String? dadoFormatado) async {
  if (dadoFormatado == null || dadoFormatado.isEmpty) {
    return '';
  }

  // Remove todos os caracteres que não são números (0-9)
  String resultado = dadoFormatado.replaceAll(RegExp(r'[^0-9]'), '');

  return resultado;
}
