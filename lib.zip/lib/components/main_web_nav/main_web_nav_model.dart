import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'main_web_nav_widget.dart' show MainWebNavWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class MainWebNavModel extends FlutterFlowModel<MainWebNavWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
